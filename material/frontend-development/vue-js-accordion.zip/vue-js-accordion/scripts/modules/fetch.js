export default async function fetchData(url, parseJSON = true) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status ${response.status}`);
    }
    if (parseJSON) {
      return await response.json();
    }
    return await response.text();
  } catch(e) {
    console.error(e);
    return false;
  }
}
