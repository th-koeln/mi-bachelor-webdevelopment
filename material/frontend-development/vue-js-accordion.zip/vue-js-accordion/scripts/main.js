// eslint-disable-next-line import/extensions
import fetchData from './modules/fetch.js';

document.addEventListener('DOMContentLoaded', () => {
  const { createApp } = Vue;
  const app = createApp(({
    template: `
    <ol class="accordion">
      <accordion
        v-for="entry in glossary"
        :description="entry.description"
        :term="entry.term"
        :key="entry.term">
      </accordion>
    </ol>
    `,
    data() {
      return {
        glossary: [],
        dataJSONUrl: '/json/user-experience-glossary.json',
      }
    },
    methods: {
      fetchData(jsonPath) {
        fetch(jsonPath)
          .then((response) => response.json())
          .then((jsonData) => {
            this.glossary = jsonData;
          });
      },
    },
    mounted() {
      this.fetchData(this.dataJSONUrl);
    },
  }));

  app.component('accordion', {
    data() {
      return {
        isCollapsed: true,
      };
    },
    props: ['term', 'description'],
    template: `
    <li>
      <h3 v-on:click="toggleAccordion">{{ term }}</h3>
      <p v-show="!isCollapsed">{{ description }}</p>
    </li>
    `,
    methods: {
      toggleAccordion() {
        this.isCollapsed = !this.isCollapsed;
      },
    },
  });

  app.mount('#app');


  const images = document.querySelectorAll('[data-blur]');
  const options = {
    threshold: 0.5,
  };

  const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.setAttribute('data-state', 'notblurred');
      }
    });
  }, options);

  images.forEach((image) => {
    imageObserver.observe(image);
  });

  class SectionObserver {
    constructor(sectionElements, navigationElement) {
      this.sectionElements = sectionElements;
      this.navigationElement = navigationElement;
      this.activeElement = null;
      const options = {
        rootMargin: '-50%',
      }
      const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const targetHash = `#${entry.target.id}`;
            const targetNavElement = this.navigationElement.querySelector(`[href="${targetHash}"]`).parentElement;
            this.refreshNavigation(targetNavElement);
          }
        });
      }, options);

      this.sectionElements.forEach((sectionElement) => {
        sectionObserver.observe(sectionElement);
      });
    }

    refreshNavigation(targetNavElement) {
      if (this.activeNavElement) {
        this.activeNavElement.removeAttribute('data-state');
      }
      targetNavElement.setAttribute('data-state', 'active');
      this.activeNavElement = targetNavElement;
    }
  }

  const sectionElements = document.querySelectorAll('[data-js-scrollspy]');
  const navElements = document.querySelector('[data-js-scrollspy-nav]');
  new SectionObserver(sectionElements, navElements);
});
