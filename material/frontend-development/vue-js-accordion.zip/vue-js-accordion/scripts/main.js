// eslint-disable-next-line import/extensions
import fetchData from './modules/fetch.js';

document.addEventListener('DOMContentLoaded', () => {
  Vue.component('accordion', {
    data() {
      return {
        isCollapsed: true,
      };
    },
    props: ['term', 'description'],
    template: `
    <li>
      <h3 v-on:click="toggleAccordion">{{ term }}</h3>
      <p v-show="!isCollapsed">{{ description }}</p>
    </li>
    `,
    methods: {
      toggleAccordion() {
        this.isCollapsed = !this.isCollapsed;
      },
    },
  });
  const app = new Vue(({
    el: '#app',
    template: `
    <ol class="accordion">
      <accordion
        v-for="entry in glossary"
        :description="entry.description"
        :term="entry.term"
        :key="entry.term">
      </accordion>
    </ol>
    `,
    data: {
      glossary: [],
      dataJSONUrl: '',
    },
    methods: {
      async fetchData(jsonPath) {
        fetch(jsonPath)
          .then((response) => response.json())
          .then((jsonData) => {
            this.glossary = jsonData;
          });
      },
    },
    beforeMount() {
      this.dataJSONUrl = this.$el.dataset.jsonUrl;
    },
    mounted() {
      this.fetchData(this.dataJSONUrl);
    },
  }));

  const images = document.querySelectorAll('[data-blur]');
  const options = {
    threshold: 0.5,
  };

  const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.setAttribute('data-state', 'notblurred');
      }
    });
  }, options);

  images.forEach((image) => {
    imageObserver.observe(image);
  });

  class SectionObserver {
    constructor(sectionElements, navigationElement) {
      this.sectionElements = sectionElements;
      this.navigationElement = navigationElement;
      this.activeElement = null;

      const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const targetHash = `#${entry.target.id}`;
            const targetNavElement = this.navigationElement.querySelector(`[href="${targetHash}"]`).parentElement;
            this.refreshNavigation(targetNavElement);
          }
        });
      });

      this.sectionElements.forEach((sectionElement) => {
        sectionObserver.observe(sectionElement);
      });
    }

    refreshNavigation(targetNavElement) {
      if (this.activeNavElement) {
        this.activeNavElement.removeAttribute('data-state');
      }
      targetNavElement.setAttribute('data-state', 'active');
      this.activeNavElement = targetNavElement;
    }
  }

  const sectionElements = document.querySelectorAll('[data-js-scrollspy]');
  const navElements = document.querySelector('[data-js-scrollspy-nav]');
  new SectionObserver(sectionElements, navElements);
});
