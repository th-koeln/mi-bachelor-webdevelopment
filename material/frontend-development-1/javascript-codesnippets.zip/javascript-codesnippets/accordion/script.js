var toggles = document.querySelectorAll('[data-accordion-toggle]');
var panels = document.querySelectorAll('[data-panel]');

for (i = 0; i < toggles.length; i++) {
  toggles[i].addEventListener('click', function() {

    this.classList.toggle('active');
    var panel = this.nextElementSibling;
    if (panel.style.height){
      panel.style.height = null;
    } else {
      panel.style.height = panel.scrollHeight + 'px';
    } 
 });
}


//Function Constructor
// function Accordion(toggle, panel) {
//   this.toggle = toggle;
//   this.panel = panel;
//   var self = this;

//   toggle.addEventListener('click', function(){
//     self.toggle.classList.toggle('active');
//     console.log(self.panel.style.height);
//     if (self.panel.style.height){

//       self.panel.style.height = null;
//     } else {
//       self.panel.style.height = self.panel.scrollHeight + 'px';
//     } 
//   });
// }

// for (i = 0; i < toggles.length; i++) { 
//   new Accordion(toggles[i], panels[i])
// }


// Cunction Constructor and Arrow Function
// function Accordion(toggle, panel) {
//   this.toggle = toggle;
//   this.panel = panel;

//   toggle.addEventListener('click', () => {
//     this.toggle.classList.toggle('active');
//     console.log(this.panel.style.height);
//     if (this.panel.style.height){

//       this.panel.style.height = null;
//     } else {
//       this.panel.style.height = this.panel.scrollHeight + 'px';
//     } 
//   });
// }

// for (i = 0; i < toggles.length; i++) { 
//   new Accordion(toggles[i], panels[i])
// }



// // Closure
// var toggles = document.querySelectorAll('[data-accordion-toggle]');
// var panels = document.querySelectorAll('[data-panel]');


// function accordion(toggle, panel) {
//   var panel = panel;
//   var toggle = toggle;
//   var exports = {};
//   var togglePanel = function() {
//     toggle.classList.toggle('active');
//     if (panel.style.height){
//       panel.style.height = null;
//     } else {
//       panel.style.height = panel.scrollHeight + 'px';
//     } 
//   };
//   exports.togglePanel = togglePanel;

//   toggle.addEventListener('click', togglePanel);
//   return exports;
// }

// for (i=0; i< toggles.length; i++) {
//   accordion(toggles[i], panels[i]);
// }
 

