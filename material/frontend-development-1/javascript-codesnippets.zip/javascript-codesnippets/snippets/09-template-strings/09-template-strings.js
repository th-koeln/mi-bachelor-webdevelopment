// Template Strings vereinfachen die Konkatenation von Zeichenketten mit variablen Werten

// Konkatenation über herkömmlichen Weg
var vorname = 'Max';
var nachname = 'Mustermann';
var meldung = 'Mein Name ist ' + vorname + ' ' + nachname;
console.log(meldung);


// Konkatenation über Template Strings
var vorname = 'Max Mustermann';
var nachname = 'Mustermann';
var meldung = `Mein Name ist ${vorname} ${nachname}`;
console.log(meldung);


// Innerhalb der geschweiften Klammern können beliebige andere Ausdrücke verwendet werden
var name = 'Max Mustermann';
function getName() {
    return name;
}

var meldung = `Mein Name ist ${getName()} und ich bin ${44 + 44} Jahre jung`;
console.log(meldung);
