// function declaration
function subtotal(price, quantity) {
  return price * quantity;
}
var result = subtotal(10, 2);


// function expression
var sub = function subtotal(price, quantity) {
  return price * quantity;
};

var result = sub(10, 2);


// anonymous function expression
var calculateSubtotal = function (price, quantity) {
  return price * quantity;
};

var result = calculateSubtotal(10, 2);