var order = {
  salesDate: "May 5, 2017",
  product: {
    type: "laptop",
    price: 500.00,
    output: function () {
      return this.type + ' $' + this.price;
    }
  },
  customer: {
    name: "Sue Smith",
    address: "123 Somewhere St",
    output: function () {
      return this.name + ', ' + this.address;
    }
  },
  output: function () {
    return 'Date' + this.salesDate;
  }
};

var consoleOutput = order.product.output();
console.log(consoleOutput);
