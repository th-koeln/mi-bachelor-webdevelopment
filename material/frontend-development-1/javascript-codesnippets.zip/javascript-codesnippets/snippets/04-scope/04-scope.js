var c = 0;
outer();

function outer() {

  function inner() {
    console.log(a);
    var b = 23;
    c = 37;
  }
  var a = 5;
  inner();
  console.log(c);
  console.log(b);
}