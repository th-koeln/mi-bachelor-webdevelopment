function calculateTotalA(price, quantity) {
  var subtotal = price * quantity;
  return subtotal + calculateTax(subtotal);

  function calculateTax(subtotal) {
    var taxRate = 0.05;
    var tax = subtotal * taxRate;
    return tax;
  }
}
console.log(calculateTotalA(20, 5));


function calculateTotalB(price, quantity) {
  var subtotal = price * quantity;
  return subtotal + calculateTax(subtotal);
  
  var calculateTax = function (subtotal) {
    var taxRate = 0.05;
    var tax = subtotal * taxRate;
    return tax;
  };
  
}
console.log(calculateTotalB(20, 5));



