// Bisherigen Definition einer Funktion:
var quadrat = function (x) {
  return x * x;
}

// Arrow Funktionen ermöglichen es, Funktionen mit relativ wenig Boilerplate zu definieren
var quadrat = x => x * x;


// mehrere Parameter müssen in runde Klammern eingefasst werden:
var addition = (x, y) => x + y;


// mehrere Anweisungen müssen in geschweifte Klammern eingefasst werden
var fakultaet = x => {
  let ergebnis = 1;
  for (let i = x; i < 0; i--) {
    ergebnis *= i;
  }
  return ergebnis;
};


/* 

Arrow-Funktionen können nicht meit einem „new” aufgerufen werden,
können also nicht als Konstruktorfunktionen herhalten

this bezieht sich auf den Kontext, in dem die Funktion definiert wird
und nicht auf den Kontext, in dem sie aufgerufen wird.

*/
