

// Variablen sind immer im gesamten Ausführungskontext sichtbar
// und nicht nur innerhalb des umgebenden Codeblocks
// => EcmaScript 5 kennt keinen Blockscope
function test() {
  var ergebnis = [];
  console.log(zahl);
  
  for (var i = 0; i < 11; i++) {
    var zahl = i;
    ergebnis[i] = function () {

      //liefert Wert außerhalb der Funktion zurück
      return zahl;
    };
  }

  for (var j=0; j< 11; j++) {
    var func = ergebnis[j];
    console.log(func());
  }

}
test();



// Emulieren von Block Scope in ES 5
function test2() {
  var ergebnis = [];
  for (var i = 0; i < 11; i++) {
    var zahl = i;
    ergebnis[i] = function(zahl2) {

      //Closure wird zurück gegeben und Parameter 'zahl 2' eingeschlossen
      return function() {
        return zahl2;
      };
    }(zahl);
  }

  for (var j=0; j< 11; j++) {
    var func = ergebnis[j];
    console.log(func());
  }

test2();

}



// Block-Scope in ES6

// Variablen die mit dem Schlüsselwort let deklariert werden,
// stehen nicht innerhalb der gesamten Funktion zur Verfügung,
// sondern nur innerhalb des Codeblocks, in dem Sie
// deklariert wurden

function test3(x) {
  console.log(y);
  if(x) {
    let y = 47111;
  }
  console.log(y);
}

test3(true);



function test4() {
  var ergebnis = [];
  
  for (var i = 0; i < 11; i++) {

    // Variable wird nicht gehoistet 
    // und bezieht sich nur auf den Scope innerhalb der Schleife
    let zahl = i;
    ergebnis[i] = function () {

      return zahl;
    }
  }

  for (var j=0; j< 11; j++) {
    var func = ergebnis[j];
    console.log(func());
  }

  // ergebnis.forEach(function(zahlFunktion) {
  //   console.log(zahlFunktion());
  // }); 


}
test4();
