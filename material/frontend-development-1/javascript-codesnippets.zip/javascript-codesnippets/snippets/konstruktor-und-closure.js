//Konstuktor Funktion
var toggles = document.querySelectorAll('[data-accordion-toggle]');
var panels = document.querySelectorAll('[data-panel]');

for (i = 0; i < toggles.length; i++) { 
  new Accordion(toggles[i], panels[i])
}

function Accordion(toggle, panel) {
  this.toggle = toggle;
  this.panel = panel;

  var self = this;

  toggle.addEventListener('click', function(){
    self.toggle.classList.toggle('active');
    if (self.panel.style.maxHeight){
      self.panel.style.maxHeight = null;
    } else {
      self.panel.style.maxHeight = self.panel.scrollHeight + 'px';
    } 
  })
}

// Arrow Function
var toggles = document.querySelectorAll('[data-accordion-toggle]');
var panels = document.querySelectorAll('[data-panel]');

for (i = 0; i < toggles.length; i++) { 
  new Accordion(toggles[i], panels[i])
}

function Accordion(toggle, panel) {
  this.toggle = toggle;
  this.panel = panel;
  toggle.addEventListener('click', () => {
    this.toggle.classList.toggle('active');
    if (this.panel.style.height){
      this.panel.style.height = null;
    } else {
      this.panel.style.height = this.panel.scrollHeight + 'px';
    } 
  });
}

// Closure
var toggles = document.querySelectorAll('[data-accordion-toggle]');
var panels = document.querySelectorAll('[data-panel]');

for (i=0; i< toggles.length; i++) {
 accordion(toggles[i], panels[i]);
}

function accordion(toggle, panel) {
  var panel = panel;
  var toggle = toggle;
  var exports = {};
  var togglePanel = function() {
    toggle.classList.toggle('active');
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + 'px';
    } 
  };
  exports.togglePanel = togglePanel;

  toggle.addEventListener('click', togglePanel);
  return exports;
}
