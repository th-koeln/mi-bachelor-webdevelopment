// Bei einer Clousre werden die Variablen und Parameter 
// der äußeren Funktion in der inneren Funktion eingeschlossen
function zaehler (name) {

  // Variable wird in der inneren Funktion eingeschlossen
  var i = 0;

  //Funktion wird beim Aufruf der äußeren Funktion zurück gegeben
  return function() {
    i++;
    console.log(name + ': ' + i);
  };
}

var zaehler1 = zaehler('testzaehler-a');
zaehler1();
zaehler1();
zaehler1();
zaehler1();
zaehler1();

var zaehler2 = zaehler('testzaehler-b');
zaehler2();
zaehler2();
