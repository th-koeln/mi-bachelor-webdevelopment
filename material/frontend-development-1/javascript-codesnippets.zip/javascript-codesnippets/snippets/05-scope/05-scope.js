var myGlobal = 55;

function outer() {
  var foo = 66;
  middle();

  function middle() {
    var bar = 77;
    inner();

    function inner() {
      var foo = 88;
      bar = foo + myGlobal;
      console.log(bar);
    }
  }
}

outer();
