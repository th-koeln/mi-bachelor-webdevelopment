# James Isaac (31)

The Shy Basketball Lover

![James Isaac](../../images/personas/james-isaac.jpg)

> When I’m playing basketball, I forget everything around me. It’s just me or me and the team. It’s a liberating feeling.

- Gender: Male
- Status: Married
- Education: Dentistry
- Occupation: Dentist
- Location: Frankfurt

## Bio

James loves watching basketball matches. If a match is broadcasted, he rushes home after work to be there in time for the kickoff. He always looks forward to weekends since he and his friends take the time to meet up and play a couple of rounds of 3-on-3 street basketball. He would love to play more during the week, but unfortunately his friends are usually too tired in the evening. He considered joining his local basketball community, but joining most teams requires a membership, and he does not want to be the "new one".

## Social Media & Communities

- Tipico Sportwetten (Facebook)
- /r NBA (Reddit)
- Instagram

## Interests

- Basketball
- NBA
- Health and Fitness
- Gaming
- Food
- NBA2K
- Movies

## Goals

- More opportunities to play
- Wants to improve his skills
- Wants to get to know strangers first before talking to them
- Wants to play normal 5v5 basketball matches

## Pains

- His friends do not have time during the week
- Joining a group full of strangers without getting to know them first is intimidating
- Does not know enough people to play normal basketball matches

## Motivations to do Sports

- Health: 70 %
- Friends: 75 %
- Personal Interest: 100 %
- Skill Improvements: 85 %
- Looks: 20 % 

## Personality

- Introvert / Extrovert: 7 / 3
- Emotional / Rational: 6 / 4
- Passive / Active: 4 / 6
- Calculated / Spontaneous: 8.5 / 1.5
- Analog / Digital: 4 / 6