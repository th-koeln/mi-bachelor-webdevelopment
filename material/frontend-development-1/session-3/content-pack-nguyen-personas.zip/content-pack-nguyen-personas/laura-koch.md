# Laura Koch

Jogger

![Laura Koch](../../images/personas/laura-koch.jpg)

> I love to do sports in my free time. But I feel lonely and want to meet people who I can talk to on my walks.

- Gender: Female
- Status: Married
- Education: Marketing
- Occupation: Social Media Manager
- Location: Kiel