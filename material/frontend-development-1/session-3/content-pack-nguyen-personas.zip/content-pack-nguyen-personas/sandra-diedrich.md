# Sandra Diedrich

The longtime handball player

![Sandra Diedrich](../../images/personas/sandra-diedrich.jpg)

> Since I've been studying, I don't find the time to play in a club any more. I think it would still be nice to play with friends from time to time.

- Gender: Female
- Status: De facto Relationship
- Education: Medicine
- Occupation: Graduate
- Location: Duisburg