# Anna Smith (24)

The Anime Fan

![Anna Smith](../../images/personas/anna-smith.jpg)

> While I love computer science, pop culture and anime, I equally enjoy partying and doing sports with my friends

- Gender: Female
- Status: Single
- Education: Computer Science
- Occupation: Graduate
- Location: Berlin

## Bio

Anna just graduated and is looking forward to her future. She is outgoing and bubbly and usually meets up with her friends after lectures. While she loves going out, she equally loves to stay at home and watch anime with pizza and popcorn. She regularly goes to the gym to balance her sedentary lifestyle when programming and watching anime. She recently discovered a series about volleyball, which made her interested in playing. Unfortunately, none of her friends are sports enthusiasts.

## Social Media & Communities   

- Board Games Geek
- MyAnimeList
- Meetup
- /r Marvelstudios (Reddit)
- LinkedIn
- Instagram
- Facebook

## Interests

- Harry Potter
- Board Games
- Anime
- Technological Advancements
- Artificial Intelligence
- Smart Home and IoT
- Food

## Goals

- "I want to play volleyball"
- Wants an alternative to going gym
- Being spontaneous when
- Easy way to find other players for volleybal

## Pains

- Not enough friends are interested in volleyball so she does not have enough players
- Does not know where to look for other players
- Gym being the only way to stay physically active is getting borin

## Motivations to do Sports

- Health: 70 %
- Friends: 30 %
- Personal Interest: 70 %
- Skill Improvements: 50 %
- Looks: 45 % 

## Personality

- Introvert / Extrovert: 4.5 / 5.5 
- Emotional / Rational: 7 / 3
- Passive / Active: 4 / 6
- Calculated / Spontaneous: 2 / 8
- Analog / Digital: 0 / 10