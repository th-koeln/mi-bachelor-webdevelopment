# Matthias Zweig

The hockey enthusiast

![Matthias Zweig](../../images/personas/matthias-zweig.jpg)

> I am a long-time fan of my local hockey club. Now I would like to play myself. But I don't dare sign up for a team because I think the hurdles are too big.

- Gender: Male
- Status: Single
- Education: Gym
- Occupation: Fitness coach
- Location: Bonn